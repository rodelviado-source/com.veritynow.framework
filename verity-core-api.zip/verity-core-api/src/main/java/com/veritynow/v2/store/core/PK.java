package com.veritynow.v2.store.core;
public record PK(String path, String hash) { } 