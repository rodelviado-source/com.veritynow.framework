package com.veritynow.v2.store.core.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InodeRepository extends JpaRepository<InodeEntity, Long> { }
