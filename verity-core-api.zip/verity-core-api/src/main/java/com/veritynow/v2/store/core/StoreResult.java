package com.veritynow.v2.store.core;

public record StoreResult(
		boolean ok,
		String message
		
) {

}
