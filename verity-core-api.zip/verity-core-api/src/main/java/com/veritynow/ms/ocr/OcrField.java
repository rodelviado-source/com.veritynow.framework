package com.veritynow.ms.ocr;

public record OcrField(String fieldId, String value, Double confidence) {}

