package com.veritynow.ms.pdf;

public record Zone(int page, float x, float y, float w, float h) {}
